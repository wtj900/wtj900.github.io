#!/bin/bash

#--------------------------------------------
# 创建日期：2019/04/26
#--------------------------------------------

###########################################常量设置###########################################

#provision profile描述文件
rightProvision="9771aaf3-a991-4fa4-b60b-ea9707ef0521"

#发布证书
rightDistributionSign="iPhone Distribution: Beijing Offcn Education & Technology Co., Ltd. (LA78A3696S)"

#蒲公英Ukey
pygerUkey=""

#蒲公英ApiKey
pygerApiKey=""

#bundleIdentifier
bundle_id="com.offcn.EasyWords"

#appName
app_name="中公易词"

#workspace
work_space="EasyWords.xcworkspace"

#scheme
scheme="EasyWords"

###########################################常量设置###########################################

#xocdebuild pre
xcode_build="xcodebuild -workspace ${work_space} -scheme ${scheme} -configuration Release DEPLOYMENT_POSTPROCESSING=YES STRIP_INSTALLED_PRODUCT=YES SEPARATE_STRIP=YES COPY_PHASE_STRIP=YES"

#工程绝对路径
project_path=$(pwd)
echo "======工程路径：${project_path}======"

#创建保存打包结果的目录
result_path=${project_path}/build/build_test_$(date +%Y-%m-%d_%H_%M)
mkdir -p "${result_path}"
echo "======最终打包路径：${result_path}======"

#工程配置文件路径
project_name=$(ls | grep xcodeproj | awk -F.xcodeproj '{print $1}')
echo "======工程文件名称：${project_name}======"
target_name=${project_name}
echo "======target名称：${target_name}======"
project_infoplist_path=${project_path}/${project_name}/Info.plist
echo "======Info.plist路径：${project_infoplist_path}======"

#取版本号
bundleShortVersion=$(/usr/libexec/PlistBuddy -c "print CFBundleShortVersionString" ${project_infoplist_path})
echo "======版本号：${bundleShortVersion}======"

#取版本号
bundleCodeVersion=$(/usr/libexec/PlistBuddy -c "print CFBundleVersion" ${project_infoplist_path})
echo "======版本号：${bundleCodeVersion}======"

#配置文件路径
buildConfig=${project_path}/Config/IPAConfig.h

#定义配置函数
###########################################定义函数###########################################

function config()
{
	#修改环境配置

	#sit
	sitConfigLine=$(grep -n "kSitTest" "${buildConfig}" | tail -1 | cut  -d  ":"  -f  1)
	if [ $sitConfigLine ]; then
		if [[ $1 = "-sit" ]]; then
			sed -i '' -e "${sitConfigLine}s/^.*$/#define kSitTest        1/" ${buildConfig}
		else
			sed -i '' -e "${sitConfigLine}s/^.*$/\/\/#define kSitTest        1/" ${buildConfig}
		fi
	else
		echo -e "\033[31m 未找到配置： kSitTest \033[0m"
	fi

	#release
	releaseConfigLine=$(grep -n "kReleaseH" "${buildConfig}" | tail -1 | cut  -d  ":"  -f  1)
	if [ $releaseConfigLine ]; then
		if [[ $1 = "-prd" ]]; then
			sed -i '' -e "${releaseConfigLine}s/^.*$/#define kReleaseH        1/" ${buildConfig}
		else
			sed -i '' -e "${releaseConfigLine}s/^.*$/\/\/#define kReleaseH        1/" ${buildConfig}
		fi
	else
		echo -e "\033[31m 未找到配置： kReleaseH \033[0m"
	fi

	#2.2 检查推送、签到服务器等配置

	#mobile dev 一直是关闭
	mDevConfigLine=$(grep -n "kMobileDevTest" "${buildConfig}" | tail -1 | cut  -d  ":"  -f  1)
	if [ $mDevConfigLine ]; then
		sed -i '' -e "${mDevConfigLine}s/^.*$/\/\/#define kMobileDevTest        1/" ${buildConfig}
	else
		echo -e "\033[31m 未找到配置： kMobileDevTest \033[0m"
	fi

	#mobile sit
	mSitConfigLine=$(grep -n "kMobileSitTest" "${buildConfig}" | tail -1 | cut  -d  ":"  -f  1)
	if [ $mSitConfigLine ]; then
		if [[ $1 = "-prd" ]]; then
			sed -i '' -e "${mSitConfigLine}s/^.*$/\/\/#define kMobileSitTest        1/" ${buildConfig}
		else
			sed -i '' -e "${mSitConfigLine}s/^.*$/#define kMobileSitTest        1/" ${buildConfig}
		fi
	else
		echo -e "\033[31m 未找到配置： kMobileSitTest \033[0m"
	fi

	#mobile release
	mReleaseConfigLine=$(grep -n "kMobileReleaseH" "${buildConfig}" | tail -1 | cut  -d  ":"  -f  1)
	if [ $mReleaseConfigLine ]; then
		if [[ $1 = "-prd" ]]; then
			sed -i '' -e "${mReleaseConfigLine}s/^.*$/#define kMobileReleaseH        1/" ${buildConfig}
		else
			sed -i '' -e "${mReleaseConfigLine}s/^.*$/\/\/#define kMobileReleaseH        1/" ${buildConfig}
		fi
	else
		echo -e "\033[31m 未找到配置： kMobileReleaseH \033[0m"
	fi

	#2.3 检查信息搜集服务器

	#snclick sit
	tSitConfigLine=$(grep -n "kSitInfoTest" "${buildConfig}" | tail -1 | cut  -d  ":"  -f  1)
	if [ $tSitConfigLine ]; then
		if [[ $2 = "-publish" ]]; then
			sed -i '' -e "${tSitConfigLine}s/^.*$/\/\/#define kSitInfoTest        1/" ${buildConfig}
		else
			sed -i '' -e "${tSitConfigLine}s/^.*$/#define kSitInfoTest        1/" ${buildConfig}
		fi
	else
		echo -e "\033[31m 未找到配置： kSitInfoTest \033[0m"
	fi

	#snclick release
	tReleaseConfigLine=$(grep -n "kReleaseInfoH" "${buildConfig}" | tail -1 | cut  -d  ":"  -f  1)
	if [ $tReleaseConfigLine ]; then
		if [[ $2 = "-publish" ]]; then
			sed -i '' -e "${tReleaseConfigLine}s/^.*$/#define kReleaseInfoH        1/" ${buildConfig}
		else
			sed -i '' -e "${tReleaseConfigLine}s/^.*$/\/\/#define kReleaseInfoH        1/" ${buildConfig}
		fi
	else
		echo -e "\033[31m 未找到配置： kReleaseInfoH \033[0m"
	fi

	#2.4 检查打印开关
	logLine=$(grep -n "define\ DEBUGLOG" "${buildConfig}" | tail -1 | cut  -d  ":"  -f  1)
	if [ $logLine ]; then
		sed -i '' -e "${logLine}s/^.*$/\/\/#define DEBUGLOG 1/" ${buildConfig}
	else
		echo -e "\033[31m 未找到配置： DEBUGLOG \033[0m"
	fi

}

##检验参数
#检查是否含-u参数，包含即上传
needUpload=false
#检查打什么包 -sit -prd 如果二者都没有，默认都打
prd_should=false
sit_should=false

#忽略证书检查
ignore_check_codesign= true

if [[ $1 = "config" ]]; then
	config $2 $3
	exit
fi

if [[ $# -gt 0 ]]; then
	for arg in "$@"
	do
		if [[ $arg = "-u" ]]; then
			needUpload=true
		elif [[ $arg = "-prd" ]]; then
			prd_should=true
		elif [[ $arg = "-sit" ]]; then
			sit_should=true
		elif [[ $arg = "-all" ]]; then
			prd_should=true
			sit_should=true
		elif [[ $arg = "-ignore-codesign" ]]; then
			ignore_check_codesign=false
		fi
	done
fi

#如果没有设置，默认都为yes
if ! $prd_should && ! $sit_should; then
	prd_should=true
	sit_should=true
fi

#编译配置打印到文件中
setting_out=${result_path}/build_setting.txt
${xcode_build}  -showBuildSettings > ${setting_out}

#编译路径
build_dir=$(grep "CONFIGURATION_BUILD_DIR" "${setting_out}" | cut  -d  "="  -f  2 | grep -o "[^ ]\+\( \+[^ ]\+\)*" | sed '2,5d')
echo "编译路径：${build_dir}"

#打包完的程序目录
appDir=${build_dir}/${target_name}.app;
echo "appDir编译路径：${appDir}"
#dSYM的路径
dsymDir=${build_dir}/${target_name}.app.dSYM;
echo "dsymDir编译路径：${dsymDir}"

if  $ignore_check_codesign; then
	#检查工程中证书的选择
	echo "======检查是否选择了正确的发布证书======"
	
	codeSign=$(grep "CODE_SIGN_IDENTITY" "${setting_out}" | cut  -d  "="  -f  2 | grep -o "[^ ]\+\( \+[^ ]\+\)*")
	echo -e ${codeSign}
	echo -e ${rightDistributionSign}

	if ["${codeSign}" != "${rightDistributionSign}"]; then
		echo -e "\033[31m 错误的证书:${codeSign}，请进入xcode选择证书为:${rightDistributionSign} \033[0m"
		exit
	fi
	#检查授权文件
	echo "======检查是否选择了正确的签名文件======"
	provisionProfile=$(grep "PROVISIONING_PROFILE[^_]" "${setting_out}" | cut  -d  "="  -f  2 | grep -o "[^ ]\+\( \+[^ ]\+\)*")
	if [ "${provisionProfile}" != "${rightProvision}" ]; then
		echo -e  "正确的配置文件UUID：${provisionProfile}"
		echo -e  "现在的配置文件UUID：${rightProvision}"
		echo -e  "\033[31m 错误的签名，请进入xcode重新选择授权文件 \033[0m"
		exit
	fi
fi

versionShort=$(echo ${bundleShortVersion} | sed "s/\./_/g")

#############################################PRD#############################################

if $prd_should; then
	#打生产环境测试包
	echo "======打生产环境的测试包======"
	echo "======修改配置中======"
	#修改bundleIdentifier
	bundleIdNew="${bundle_id}${versionShort}prd"
	/usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundle_id}" ${project_infoplist_path}
	#修改环境配置
	config -prd;
	#国际化名称
	# infoString=${project_path}/${project_name}/zh-Hans.lproj/InfoPlist.strings
	# sed -i '' -e "4s/^.*$/CFBundleDisplayName = \"PRD${versionShort}.$(date +%m%d)\";/" ${infoString}
	echo "======开始clean工程,打prd渠道包======"
	${xcode_build} clean
	#编译工程
	${xcode_build} -sdk iphoneos build || exit
	
	#ipa名称
	bundleShowName="${app_name}_正式_${versionShort}_code(${bundleCodeVersion})"
	ipa_name="${result_path}/${bundleShowName}.ipa"
	#先打第一个appStore渠道的包
	xcrun -sdk iphoneos PackageApplication -v "${appDir}" -o "${ipa_name}"
	#xcrun -sdk iphoneos PackageApplication -v "${appDir}" -o "${ipa_name}" --sign "${enterpriseSign}" --embed "${enterpriseEmbed}"
	#拷贝过来.app和.app.dSYM放在子目录
	mkdir -p "${result_path}/prd"
	cp -R "${appDir}" "${result_path}/prd/${target_name}.app"
	cp -R "${dsymDir}" "${result_path}/prd/${target_name}.app.dSYM"

	#上传测试包prd
	if $needUpload; then
        echo "======上传中======"

        #上传蒲公英
        curl -F "file=@${ipa_name}" \
        -F "uKey=${pygerUkey}" \
        -F "_api_key=${pygerApiKey}" \
        https://www.pgyer.com/apiv2/app/upload

        echo "======上传完成======"

        #发送通知邮件
        python sendEmail.py "${bundleShowName}上传成功"

	fi
fi


#############################################SIT#############################################

if $sit_should; then
	#打SIT环境测试包
	echo "======打SIT环境的测试包======"
	echo "======修改配置中======"
	#修改bundleIdentifier
	bundleIdNew="${bundle_id}${versionShort}sit"
	/usr/libexec/PlistBuddy -c "set CFBundleIdentifier ${bundle_id}" ${project_infoplist_path}
	#修改环境配置
	config -sit
	# #国际化名称
	# infoString=${project_path}/${project_name}/zh-Hans.lproj/InfoPlist.strings
	# sed -i '' -e "4s/^.*$/CFBundleDisplayName = \"SIT${versionShort}.$(date +%m%d)\";/" ${infoString}
	echo "======开始clean工程,打sit渠道包======"
	${xcode_build} clean

	#编译工程
	${xcode_build} -sdk iphoneos build || exit
	
	#ipa名称
	bundleShowName="${app_name}_测试_${versionShort}_code(${bundleCodeVersion})"
	ipa_name="${result_path}/${bundleShowName}.ipa"
	#先打第一个appStore渠道的包
	xcrun -sdk iphoneos PackageApplication -v "${appDir}" -o "${ipa_name}"
	#xcrun -sdk iphoneos PackageApplication -v "${appDir}" -o "${ipa_name}" --sign "${enterpriseSign}" --embed "${enterpriseEmbed}"
	#拷贝过来.app和.app.dSYM放在子目录
	mkdir -p "${result_path}/sit"
	cp -R "${appDir}" "${result_path}/sit/${target_name}.app"
	cp -R "${dsymDir}" "${result_path}/sit/${target_name}.app.dSYM"

	#上传测试包sit
	if $needUpload; then
        echo "======上传中======"

        #上传蒲公英
        curl -F "file=@${ipa_name}" \
        -F "uKey=${pygerUkey}" \
        -F "_api_key=${pygerApiKey}" \
        https://www.pgyer.com/apiv2/app/upload

        echo "======上传完成======"

        #发送通知邮件
        python sendEmail.py "${bundleShowName}上传成功"

	fi
fi

