#! /usr/bin/env python
#coding=utf-8

import sys
from email.mime.text import MIMEText
from email.header import Header
from smtplib import SMTP_SSL

##################需要配置的变量##########################

#sender_offcn为发件人的邮箱
sender_offcn = 'wangdongsheng@offcn.com'
#pwd为邮箱的密码
pwd = 'wds213506'
#收件人邮箱
receiver = ['274511903@qq.com']
#下载链接
download_url = 'https://www.google.com/'

##################需要配置的变量##########################

#offcn邮箱smtp服务器
host_server = 'mail.offcn.com'
#发件人的邮箱
sender_offcn_mail = sender_offcn

def send_mail(title):

    try:
        #邮件的正文内容
        mail_content = """
            <p>赶紧下载体验吧！</p>
            <p><a href="%s">这是下载链接</a></p>
            """ %(download_url)
        #邮件标题
        mail_title = title

        #ssl登录
        smtp = SMTP_SSL(host_server)
        #set_debuglevel()是用来调试的。参数值为1表示开启调试模式，参数值为0关闭调试模式
#        smtp.set_debuglevel(1)
        smtp.ehlo(host_server)
        smtp.login(sender_offcn, pwd)

        #文本格式
        #msg = MIMEText(mail_content, "plain", 'utf-8')
        #html格式
        msg = MIMEText(mail_content, "html", 'utf-8')

        msg["Subject"] = Header(mail_title, 'utf-8')
        msg["From"] = sender_offcn_mail
        msg["To"] = receiver
        smtp.sendmail(sender_offcn_mail, receiver, msg.as_string())
        smtp.quit()
        return True
    except Exception, e:
        print str(e)
        return False

if send_mail(sys.argv[1]):
    print "\033[32m send mail success! \033[0m"
else:
    print "\033[31m send mail failed! \033[0m"
